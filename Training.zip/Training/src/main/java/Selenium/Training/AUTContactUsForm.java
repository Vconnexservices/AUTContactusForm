package Selenium.Training;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 
 * @author Vconnex Services, Inc
 * @Date Aug 2020
 * This is the sample script to test Contact Us form of any website. 
 *
 */
public class AUTContactUsForm {

	public static void main(String[] args) throws IOException {
		// set the path of the driver for the Chrome Browser
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		// Set Application URL to navigate
		driver.get("https://www.vconnexservices.com/");
		
		//To maximize a browser window, call the maximize() method of the Window interface of the driver
		driver.manage().window().maximize();
		
		// click AUT_Contactus_Form Link
		driver.findElement(By.xpath("//a[text()='Contact']")).click();
		
		// Set dataset path-This file includes contactus form details(Name, Email, Phone, Subject, Message)
		String strPath = System.getProperty("user.dir") + "\\TestData\\data.xlsx";
		
		File file = new File(strPath);
		FileInputStream fis = new FileInputStream(file);
		//create an object of Workbook and pass the FileInputStream object into it to create a pipeline between the sheet and eclipse.
		Workbook workbook = new XSSFWorkbook(fis);

		// call the getSheet() method of Workbook and pass the Sheet Name here.
		Sheet sheetName = workbook.getSheet("Contact Us-Input");

		// Find number of rows in excel file
		int rowCount = sheetName.getLastRowNum() - sheetName.getFirstRowNum();
		
		// Parse and enter the data into the form
		for (int i = 1; i < rowCount + 1; i++) {
			Row row = sheetName.getRow(i);
			// Enter text into the First and Last Name text box
			driver.findElement(By.xpath("//input[@id='name']")).sendKeys(row.getCell(0).getStringCellValue());
			
			// Enter text into the email text box
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys(row.getCell(1).getStringCellValue());
			
			// Enter text into the subject text box
			driver.findElement(By.xpath("//input[@id='subject']")).sendKeys(row.getCell(2).getStringCellValue());
			
			// Enter text into the phone text box
			driver.findElement(By.xpath("//input[@id='phone']")).sendKeys(row.getCell(3).getStringCellValue());
			
			// Enter text into the Message text box
			driver.findElement(By.xpath("//textarea[@id='message']")).sendKeys(row.getCell(4).getStringCellValue());
			
			// Click Send button
			driver.findElement(By.xpath("//input[@id='submit']")).click();
		}
	}
}
